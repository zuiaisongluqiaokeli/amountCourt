const state = {
  userAgent: 'proxy', // 用户身份
  plantiffId: 'plant_0', // 原告ID
  agentId: 'agent_0', // 代理人ID
  plantiffNum:0, //原告计数
  agentNum:0, //原告计数
  plantiffStr:'plant_', //原告随机字符串
  agentStr:'agent_', //代理人随机字符串
}

export default state
