import state from './state'
import mutations from './mutations'

const setcaseModules = {
  state,
  mutations
}

export default setcaseModules;
