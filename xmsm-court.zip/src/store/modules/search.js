const search = {
    state: {
        caseNo: ''
    },
    mutations: {
        SET_CASENO: (state, caseNo) => {
            state.caseNo = caseNo;
        }
    }
}
export default search;
