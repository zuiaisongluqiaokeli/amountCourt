<template>
 <div>
历史委托人信息
 </div>
</template>

<script>
 export default {
   components: {

   },
   data () {
     return {

     }
   },
 }
</script>

<style>

 
</style>
