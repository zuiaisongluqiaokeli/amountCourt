// 账户安全信息密码表单数据
const pwdList = {
    old_pwd: '', // 旧密码
    new_pwd: '', //新密码
    pwd_check: '', //新密码校验
}

// 账户安全信息手机表单数据
const phoneList = {
    old_phone: '', // 旧手机
    user_pwd: '', //用户密码
    new_phone: '', //新手机
    phone_check: '', //手机验证码校验
}


const accountInfo = {
    pwdList,
    phoneList,
}
export default accountInfo