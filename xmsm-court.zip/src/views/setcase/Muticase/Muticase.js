const mutiCaseStep = [
  {
    "step": "1",
    "stepName": "要素模板批量导入"
  },
  {
    "step": "2",
    "stepName": "证明文件上传"
  },
  {
    "step": "3",
    "stepName": "证据批量上传"
  },
  {
    "step": "4",
    "stepName": "送达事项确认"
  },
  {
    "step": "5",
    "stepName": "预览与暂存"
  },
  {
    "step": "6",
    "stepName": "成功提交"
  },
]

export default mutiCaseStep;