import Upload from './upload.vue';

export default Upload;
