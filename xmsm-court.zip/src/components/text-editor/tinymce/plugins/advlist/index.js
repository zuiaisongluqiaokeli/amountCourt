// Exports the "advlist" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/advlist')
//   ES2015:
//     import 'tinymce/plugins/advlist'
require('./plugin.js');
